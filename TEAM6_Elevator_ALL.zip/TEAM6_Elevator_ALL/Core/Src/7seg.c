
#include "7seg.h"


void dataOut_SEG(uint8_t data)
{
    /*
     * i = 7 → 0
     * MSB부터 LSB까지 순차적으로 전송
     */
	for(int i = 7; i >= 0; i--)
	{
        /*
         * 현재 전송할 비트를 SER 핀에 출력
         * data의 i번째 비트가 1이면 HIGH, 0이면 LOW
         *
         * 이 시점에서는 아직 74HC595 내부로 들어가지 않고
         * 단순히 입력 핀에 값만 세팅된 상태
         */
		if(data & (1 << i))
		{

			HAL_GPIO_WritePin(SER_PORT_SEG, SER_PIN_SEG, GPIO_PIN_SET);
		}
		else
		{
			HAL_GPIO_WritePin(SER_PORT_SEG, SER_PIN_SEG, GPIO_PIN_RESET);
		}

        /*
         * SRCLK(Shift Clock) 펄스 생성
         *
         * - SRCLK의 상승엣지에서 SER 값이
         *   내부 쉬프트 레지스터로 이동
         * - 이후 비트들은 한 칸씩 밀려남
         *
         * delay_us()는 setup/hold time 확보용 여유
         */
		HAL_GPIO_WritePin(SRCLK_PORT_SEG, SRCLK_PIN_SEG, GPIO_PIN_SET);
		delay_us(5);

		HAL_GPIO_WritePin(SRCLK_PORT_SEG, SRCLK_PIN_SEG, GPIO_PIN_RESET);
		delay_us(5);
	}

    /*
     * RCLK(Latch Clock) 펄스 생성
     *
     * - 지금까지 쉬프트 레지스터에 쌓인 8비트 데이터를
     *   출력 래치로 복사
     * - QA~QH 핀이 이 순간에만 갱신됨
     *
     * 장점:
     * - 데이터 전송 중에는 출력이 바뀌지 않음
     * - LED/FND 사용 시 중간 상태가 보이지 않음
     */
	HAL_GPIO_WritePin(RCLK_PORT_SEG, RCLK_PIN_SEG, GPIO_PIN_SET);
	delay_us(10);
	HAL_GPIO_WritePin(RCLK_PORT_SEG, RCLK_PIN_SEG, GPIO_PIN_RESET);
}


static const uint8_t SEG_NUMBER[10] = {
    0x3F, 0x06, 0x5B, 0x4F, 0x66,
    0x6D, 0x7D, 0x27, 0x7F, 0x67
};

void SEVEN_SEG_Init()
{
	dataOut_SEG(SEG_NUMBER[1]);
}

void SEVEN_SEG(uint8_t floor)
{
	dataOut_SEG(SEG_NUMBER[floor]);
}


